#include<stdio.h>
void main()
{
	int a;
	printf("enter your value\n");
	scanf("%d",&a);
	if(a>=0)
	{
		if(a==0)
		{
			printf("%d is zero",a);
		}
		else
		{
			printf("%d is positive",a);
		}
	}
	else
	{
		printf("%d is negative",a);
	}
}
