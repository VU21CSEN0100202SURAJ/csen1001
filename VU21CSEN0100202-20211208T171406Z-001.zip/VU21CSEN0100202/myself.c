#include<stdio.h>
void main()
{
	printf("My\tname\tis\tSuraj\tPragallapati\t");
	printf("I\tam\tfrom\tRajahmundry\t");
	printf("My\tfather's\tname\tis\tSrinivas\t");
	printf("I\tam\t\tstudying\tCSE\tin\tGitam\tuniversity\t");
	printf("I\tam\tinterested\tin\tsports\tand\tphotography\t");
	printf("My\taim\tis\tto\tstart\ta\tbusiness");
}
