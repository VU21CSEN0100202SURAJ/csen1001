#include<stdio.h>
void main()
{
	int a,b,c,d,e;
	printf("enter values of a and b\n");
	scanf("%d%d",&a,&b);
	c=a>b&&a<b;
	printf("%d>%d&&%d<%d=%d\n",a,b,a,b,c);
	d=a>b||a<b;
	printf("%d>%d||%d<%d=%d\n",a,b,a,b,d);
	e=!(a>b&&a<b);
	printf("!(%d>%d&&%d<%d)=%d",a,b,a,b,e);
}
