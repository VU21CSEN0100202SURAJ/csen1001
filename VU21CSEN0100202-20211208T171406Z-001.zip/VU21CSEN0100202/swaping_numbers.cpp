//wap to swap two numbers using temporary variable
#include<stdio.h>
main()
{
	int a,b,c;
	printf("enter one number=");
	scanf("%d",&a);
	printf("enter second number=");
	scanf("%d",&b);
	c=a;
	a=b;
	b=c;
	printf("the swaped 1st number%d",a);
	printf("the swaped 2nd number%d",b);
	return 0;
}

