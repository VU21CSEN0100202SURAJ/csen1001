#include<stdio.h>
void main()
{
	int a;
	printf("enter number");
	scanf("%d",&a);
	(a>0)?printf("%d is positive",a):printf("%d is negative",a);
}
