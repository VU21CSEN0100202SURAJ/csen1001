//wap to print the digit at ones place of a number
#include<stdio.h>

int main()

{
    
	int num,digit;
	printf("Enter a number:");
	scanf("%d",&num);

	digit=num%10;
	printf("ones place: %d",digit);
    
	return 0;

}

