/**
  * NAME:
  * DATE:
  * FILE:
  * COMMENTS:
  */

public class numbers in reverse order extends eecs.Gui
{
   public static void main(String[] args)
   {
      // declare variables
      String raptor_prompt_variable_zzyz = null;
      ?? i = ??;
      ?? n = ??;
      
      raptor_prompt_variable_zzyz = "enter the number";
      n = get???(raptor_prompt_variable_zzyz);
      i = n;
      while (i < 1)
      {
         printLine(i);
         i = i - 1;
      }
   } // close main
} // close numbers in reverse order
