#include<stdio.h>
void main()
{
	int P,T,R,SIMPLEINTEREST;
	printf("enter principle time rate\n");
	scanf("%d%d%d",&P,&T,&R);
	SIMPLEINTEREST=(P*T*R)/100;
	printf("SIMPLE INTEREST IS %d",SIMPLEINTEREST);
}
