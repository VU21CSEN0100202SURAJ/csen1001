#include<stdio.h>
void main()
{
	char ch;
	printf("enter values");
	scanf("%c",&ch);
	if(ch>=65&&ch<=90)
	{
		ch=ch+32;
	}
	if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
	{
		printf("%c is a vowel",ch);
	}
	else
	{
		printf("%c is a consonent",ch);
	}
}
