#include<stdio.h>
int main()
{
	float cm,km;
	printf("enter the value of cm");
	scanf("%f",&cm);
	km=1/100000cm;
	printf("km is  %f",km);
}
