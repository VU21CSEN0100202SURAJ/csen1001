#include<stdio.h>
void main()
{
	int a;
	printf("enter percentage of student\n");
	scanf("%d",&a);
	if(a>=90&&a<=100)
	printf("grade O");
	else if(a>=75&&a<=89)
	printf("grade A");
	else if(a>=60&&a<=74)
	printf("grade B");
	else if(a>=40&&a<=59)
	printf("grade c");
	else if(a<=40)
	printf("grade F");
	else
	printf("not a percentage");
}
