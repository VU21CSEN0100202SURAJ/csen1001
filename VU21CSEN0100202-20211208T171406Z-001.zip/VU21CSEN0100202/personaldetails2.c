#include<stdio.h>
void main()
{
	printf("Suraj\nVU21CSEN0100202\nGITAM\nCSE");
}
