#include<stdio.h>
#include<math.h>
void main()
{
	float a,b,c,r1,r2,d,real,img;
	printf("enter values");
	scanf("%f%f%f",&a,&b,&c);
	d=b*b-4*a*c;
	if(d>=0)
	{
		if(d==0)
		{
			printf("roots are real and equal\n");
			r1=-b/2*a;
			r2=-b/2*a;
			printf("root1=%f\troot2=%f\t",r1,r2);
		}
		else
		{
			printf("roots are real and distinct\n");
			r1=(-b+sqrt(d))/2*a;
			r2=(-b-sqrt(d))/2*a;
			printf("root1=%f\n root2=%f\n",r1,r2);
		}
	}
	else
	{
		printf("roots are imaginary\n");
		real=-b/2*a;
		img=sqrt(-d)/2*a;
		printf("root1=%f+%fi\t root2=%f-%fi",real,img,real,img);
	}
}
