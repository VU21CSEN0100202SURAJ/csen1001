//wap to find the length of straight lines formed by 2 points who coordinates
#include<stdio.h>
int main()
{
    int x1,y1,x2,y2;
	float length;
	printf("enter x coordinate of point 1");
	scanf("%d",&x1);
	printf("enter y coordinate of point 1");
	scanf("%d",&y1);
	printf("enter x coordinate of point 2");
	scanf("%d",&x2);
	printf("enter y coordinate of point 2");
	scanf("%d",&y2);
	length=sqrt((x2-x1 )*(x2-x1)+(y2-y1)*(y2-y1));
	printf("the length of the line is%f",length);
}
