#include<stdio.h>
main()
{
	printf("number=%06 if\n",5.5)
}
