#include<stdio.h>
void main()
{
	int a,b,c;
	printf("enter your values\n");
	scanf("%d%d%d",&a,&b,&c);
	if(a==b&b==c)
	{
		printf("traingle is equilateral");
	}
	else
	{
		if(a==b|b==c|c==a)
		{
			printf("triangle is isosceles");
		}
		else
		{
			printf("triangle is scalene");
		}
	}
}
