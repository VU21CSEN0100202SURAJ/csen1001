#include<stdio.h>
void main()
{
	int a;
	printf("enter year\n");
	scanf("%d",&a);
	if(a%4==0)
	{
		if(a%100!=0a%400==0)
		{
			printf("%d is leap year",a);
		}
		else
		{
			printf("%d is not a leap year",a);
		}
	}
	else
	{
		printf("%d is not a leap year",a);
	}
}
