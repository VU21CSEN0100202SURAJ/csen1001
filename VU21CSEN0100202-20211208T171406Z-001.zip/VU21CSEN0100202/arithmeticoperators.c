#include<stdio.h>
void main()
{
	int a,b,add,sub,mul,div,mod;
	printf("enter your value of a and b\n");
	scanf("%d%d",&a,&b);
	add=a+b;
	printf("%d+%d=%d\n",a,b,add);
	sub=a-b;
	printf("%d-%d=%d\n",a,b,sub);
	mul=a*b;
	printf("%d*%d=%d\n",a,b,mul);
	div=a/b;
	printf("%d/%d=%d\n",a,b,div);
	mod=a%b;
	printf("%d mod %d = %d",a,b,mod);
}
