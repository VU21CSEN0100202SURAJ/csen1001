#include<stdio.h>
main()
{
	float a,b,c,d,e,tot,per,cgpa;
	printf("enter a value");
	scanf("%f",&a);
	printf("enter b value");
	scanf("%f",&b);
	printf("enter c value");
	scanf("%f",&c);
	printf("enter d value");
	scanf("%f",&d);
	printf("enter e value");
	scanf("%f",&e);
	tot=a+b+c+d+e;
	per=(tot)/5*(100)*(0.9);
	;
	if (cgpa>=6)
	{
		printf("eligible");
	}
	else 
	{
		printf("not eligible");
		
	}
	return 0;
	
	}
