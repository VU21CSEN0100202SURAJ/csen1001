#include<stdio.h>
void main()
{
	int a,b,c,d;
	printf("enter values\n");
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(a<b&&a<c&&a<d)
	printf("%d is minimum",a);
	else if(b<a&&b<c&&b<d)
	printf("%d is minimun",b);
	else if(c<a&&c<b&&c<d)
	printf("%d is minimum",c);
	else
	printf("%d is minimum",d);
}
