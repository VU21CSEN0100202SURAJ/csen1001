#include<stdio.h>
void main()
{
	int a;
	printf("enter person's age");
	scanf("%d",&a);
	(a>=18)?printf("person is eligible"):printf("person is not eligible");
}
