#include<stdio.h>
void main()
{
	int a=10000325;
	int b=-10;
	unsigned int c=-10;
	short int x=50;
	printf("%d\n",a);
	printf("%d\n",b);
	printf("%u\n",c);
	printf("%d\n",x);
}
