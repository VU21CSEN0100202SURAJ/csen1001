#include<stdio.h>
int main()
{
	printf("number=%06.1f\n",5.5);
	printf("%-+6.1f=number\n",5.5);
	printf("VAT=17.5%%n");
	printf("%-6.3if\n",17.23478);
}
