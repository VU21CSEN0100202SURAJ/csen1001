#include<stdio.h>
void main()
{
	int a,b;
	printf("enter values of a and b\n");
	scanf("%d%d",&a,&b);
	printf("a&b = %d\n",a&b);
	printf("a|b = %d\n",a|b);
	printf("a^b = %d\n",a^b);
	printf("a<<2 = %d\n",a<<2);
	printf("a>>2= %d",a>>2);
}
