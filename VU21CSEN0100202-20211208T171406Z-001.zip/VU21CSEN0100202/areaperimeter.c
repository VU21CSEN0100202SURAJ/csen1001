#include<stdio.h>
void main()
{
	float r,area,perimeter;
	printf("enter radius");
	scanf("%f",&r);
	area=3.14*r*r;
	perimeter=2*3.14*r;
	printf("the area is %f and perimeter is %f",area,perimeter);
}
