//wap to caluculate total amount of money in piggy bank 
#include<stdio.h>
main()
{
	int a,b,c,d,total;
	printf("enter number of 10 rupee coins");
	scanf("%d",&a);
	printf("enter number of 5 rupee coins");
	scanf("%d",&b);
	printf("enter number of 2 rupee coins");
	scanf("%d",&c);
	printf("enter number of 1 rupee coins ");
	scanf("%d",&d);
	total=10*a+5*b+2*c+d*1;
	printf("the total amount is %d",total);
	return 0;	
}
