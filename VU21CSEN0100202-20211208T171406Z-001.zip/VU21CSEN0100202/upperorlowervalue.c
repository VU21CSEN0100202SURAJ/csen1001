#include<stdio.h>
void main()
{
	char ch;
	printf("enter value\n");
	scanf("%c",&ch);
	if(ch>=65&&ch<=90)
	{
		printf("%c is upper case",ch);
	}
	else
	{
		printf("%c is lower case",ch);
	}
}
