#include<stdio.h>
void main()
{
	int a;
	printf("enter value");
	scanf("%d",&a);
	if(a%5==0&a%7==0)
	{
			printf("number is divisible by 5 & 7");
	}
	else
	{
		printf("number is not divible");
	}
}
