#include<stdio.h>
void main()
{
	int a;
	float b;
	char x;
	printf("size of integer =%d\n",sizeof(a));
	printf("size of float = %d\n",sizeof(b));
	printf("size of char = %d\n",sizeof(x));
}
