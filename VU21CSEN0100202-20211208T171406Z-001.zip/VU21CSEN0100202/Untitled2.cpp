#include<stdio.h>
int main()
{
int a;	
printf("enter the value of a");
	scanf("%d",&a);
	
		
	if	(a/2==0)
	
	{
		
	printf("if is 0 even no");
	{
	else
	printf("if not 0 odd no")
	}
}
