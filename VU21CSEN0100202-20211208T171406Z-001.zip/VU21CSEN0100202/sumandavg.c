#include<stdio.h>
void main()
{
	int a,b,c,sum;
	float avg;
	printf("enter 3 numbers\n");
	scanf("%d%d%d",&a,&b,&c);
	sum=a+b+c;
	avg=sum/3;
	printf("sum is %d average is %f",sum,avg);
}
