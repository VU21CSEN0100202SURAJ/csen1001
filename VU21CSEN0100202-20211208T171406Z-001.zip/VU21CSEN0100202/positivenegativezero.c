#include<stdio.h>
void main()
{
	int a;
	printf("enter value\n");
	scanf("%d",&a);
	if(a>0)
	{
		printf("%d is positive",a);
	}
	if(a<0)
	{
		printf("%d is negative",a);
	}
	if(a==0)
	{
		printf("%d = 0",a);
	}
}
