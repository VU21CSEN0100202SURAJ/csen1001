#include <stdio.h>
int main() {
    int a,b,c;
  printf("side a");
  scanf("%d",&a);
   printf("side b");
  scanf("%d",&b);
   printf("side c");
  scanf("%d",&c);
      if(a==b&a==c)
      {
      printf("equilateral triangle ");
  }
  else if(b==c&c!=a||a==b&b!=c||c==a&a!=b)
  {
      printf("isoceles triangle");
      }
      else
      printf("scalene");
  {
  }
 return 0;
}
