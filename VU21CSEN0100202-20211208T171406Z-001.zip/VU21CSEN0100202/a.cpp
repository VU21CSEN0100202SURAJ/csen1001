#include<stdio.h>;
int main ()
{

int a,n;
printf("enter values a  ");
scanf("%d",&a);
printf("enter values b");
scanf("%d",&b);
printf("enter values c");
scanf("%d",&c);
if(a>b)
{
printf(" %d",a);
}
else
{
	printf(" %d",b);
}
if (b>c)
{
	printf(%d",c")
}
	


return 0;
}



