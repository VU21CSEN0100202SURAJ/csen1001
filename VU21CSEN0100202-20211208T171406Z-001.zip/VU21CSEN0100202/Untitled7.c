#include<stdio.h>
int main()
{
    int basic,HRA,DA,z;
    scanf("%d",&basic);
    HRA=(25*basic)/100;
    DA=(80*basic)/100;
    z=basic+DA+HRA;
    printf("%d",z);
}
