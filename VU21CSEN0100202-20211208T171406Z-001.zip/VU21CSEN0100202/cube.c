#include<stdio.h>
void main()
{
	int a,cube;
	printf("enter your number");
	scanf("%d",&a);
	cube=a*a*a;
	printf("the cube of %d is %d",a,cube);
}
