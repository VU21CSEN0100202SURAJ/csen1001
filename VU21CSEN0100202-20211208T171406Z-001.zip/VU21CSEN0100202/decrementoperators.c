#include<stdio.h>
void main()
{
	int a,b;
	printf("enter numbers\n");
	scanf("%d%d",&a,&b);
	printf("initial values are %d\t%d\n",a,b);
	b=--a;
	printf("predecrement values are %d\t%d\n",a,b);
	b=a--;
	printf("postdecrement values are %d\t%d",a,b);
}
