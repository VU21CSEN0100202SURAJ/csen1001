#include<stdio.h>
main()
{
	float c,f;
	printf(" enter farenheit value");
	scanf("%f",&f);
	c=(f-32)*5/9;
	printf("temparature in celcius %f",c);
	return 0;
	
}
