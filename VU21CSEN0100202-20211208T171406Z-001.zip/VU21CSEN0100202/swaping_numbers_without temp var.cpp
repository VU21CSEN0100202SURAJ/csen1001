//wap to swap two numbers without using temporary variable
#include<stdio.h>
main()
{
	int a,b;
	printf("enter the 1st number");
	scanf("%d",&a);
	printf("enter the 2nd number");
	scanf("%d",&b);
	printf("a=%d,b=%d",a,b);
	a=a+b;
	b=b-a;
	a=a-b;
	printf("after swaping %d,%d",a,b);
	return 0;
}
