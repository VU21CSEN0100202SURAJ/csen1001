#include<stdio.h>
void main()
{
	printf("om\tnamah\tsivaya");
}
