#include<stdio.h>
void main()
{
	printf("Suraj\tVU21CSEN0100202\tCSE");
}
