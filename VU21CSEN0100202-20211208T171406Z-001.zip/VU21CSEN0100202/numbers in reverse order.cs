using System;
using System.IO;
using System.Text;

namespace numbers in reverse order
{
   public class main_class
   {
      static System.Random random_generator = new System.Random();
      public static void Main(string[] args)
      {
         string raptor_prompt_variable_zzyz;
         ?? i;
         ?? n;
      
         raptor_prompt_variable_zzyz ="enter the number";
         Console.WriteLine(raptor_prompt_variable_zzyz);
         n= Double.Parse(Console.ReadLine());
         i =n;
         while (!(i<1))
         {
            Console.WriteLine(i);
            i =i-1;
         }
      }
   }
}
