#include<stdio.h>
void main()
{
	char ch;
	printf("enter value\n");
	scanf("%c",&ch);
	if(ch>=65&&ch<=90);
	{
		ch=ch+32;
		printf("%c",ch);
	}
}
