#include<stdio.h>
void main()
{
	int a,b,sum,sub,mul;
	float div;
	printf("enter 2 numbers\n");
	scanf("%d%d",&a,&b);
	sum=a+b;
	sub=a-b;
	mul=a*b;
	div=a/b;
	printf("sum is %d\n",sum);
	printf("substraction is %d\n",sub);
	printf("multiplication is %d\n",mul);
	printf("division is %f",div);
}
