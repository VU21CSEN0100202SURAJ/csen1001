#include<stdio.h>
void main()
{
	char ch;
	printf("enter value\n");
	scanf("%c",&ch);
	if(ch>=97&&ch<=122)
	{
		ch=ch-32;
		printf("%c",ch);
	}
}
