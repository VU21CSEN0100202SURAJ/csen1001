#include<stdio.h>
void main()
{
	int a;
	printf("enter age\n");
	scanf("%d",&a);
	if(a>=18)
	{
		printf("person is eligible for voting");
	}
	else
	{
		printf("person is not eligible for voting");
	}
}
