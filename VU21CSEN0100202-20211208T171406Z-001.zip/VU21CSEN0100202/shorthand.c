#include<stdio.h>
void main()
{
	int a,b=10;
	printf("enter the value of a");
	scanf("%d",&a);
	b+=a;
	printf("b=%d\n",b);
	b-=a;
	printf("b=%d\n",b);
	b*=a;
	printf("b=%d\n",b);
	b!=a;
	printf("b=%d\n",b);
	b%=a;
	printf("b=%d\n",b);
}
