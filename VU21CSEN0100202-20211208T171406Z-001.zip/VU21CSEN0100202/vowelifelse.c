#include<stdio.h>
void main()
{
	char x;
	printf("enter character\n");
	scanf("%c",&x);
	if(x=='a'||x=='A')
	printf("a is vowel");
	else if(x=='e'||x=='E')
	printf("e is vowel");
	else if(x=='i'||x=='I')
	printf("i is vowel");
	else if(x=='o'||x=='O')
	printf("o is vowel");
	else if(x=='u'||x=='U')
	printf("u is vowel");
	else
	printf("%c is consonant",x);
}
