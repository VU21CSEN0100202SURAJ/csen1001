#include<stdio.h>
void main()
{
	int a=5,b=3,c=2,d=4,e=2,x,y,z,p,q;
	x=a+b-c+d*e;
	y=(a/b+d*e)-c;
	z=((a+b)*(c-d))+d/e;
	p=a+b%c-e;
	q=a*(b/c-b+d);
	printf("x=%d\ny=%d\nz=%d\np=%d\nq=%d\n",x,y,z,p,q);
	
}
