#include<stdio.h>
void main()
{
	char x;
	printf("enter character\n");
	scanf("%c",&x);
	if(x=='v'||x=='V')
	printf("violet");
	else if(x=='i'||x=='I')
	printf("indigo");
	else if(x=='b'||x=='B')
	printf("blue");
	else if(x=='g'||x=='G')
	printf("green");
	else if(x=='Y'||x=='y')
	printf("yellow");
	else if(x=='o'||x=='O')
	printf("orange");
	else if(x=='r'||x=='R')
	printf("red");
	else
	printf("not a VIBGYOR COLOUR");
}
