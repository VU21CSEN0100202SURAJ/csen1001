#include<stdio.h>
void main()
{
	int a,b;
	printf("enter numbers\n");
	scanf("%d%d",&a,&b);
	printf("initial values are %d\t%d\n",a,b);
	b=++a;
	printf("preincrement values are %d\t%d\n",a,b);
	b=a++;
	printf("postincrement values are %d\t%d",a,b);
}
