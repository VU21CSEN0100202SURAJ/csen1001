#include<stdio.h>
int main()
{  

	char ch;
	printf("enter the alphabet");
	scanf("%c",&ch);
	
	switch (ch)
	{
		 case 'a':
			printf("vowel");
			break;
			case 'e':
			
				
				printf("vowel");
					break;
				case 'i':
			printf("vowel");
			break;
				case 'o':
			printf("vowel");
			break;	
			case 'u':
			printf("vowel");
			break;
			// ch doesn't match any constanta,e,i,o,u
			default:
				printf("consonant");
				}
				
				
return 0;
}
